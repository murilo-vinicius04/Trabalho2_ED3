#ifndef FUNCOES_FORNECIDAS
#define FUNCOES_FORNECIDAS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void scan_quote_string(char *str);

void binarioNaTela(char *nomeArquivoBinario);

long converteNome(char* str);

#endif
